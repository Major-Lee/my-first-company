package com.bhu.vas.business.backendonline.asyncprocessor.service.impl.batchimport.dto;

public class DeviceCallbackDTO {
	private String mac;

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}
	
	
}
