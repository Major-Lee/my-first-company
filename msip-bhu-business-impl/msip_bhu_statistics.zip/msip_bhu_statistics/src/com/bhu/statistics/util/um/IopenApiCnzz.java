package com.bhu.statistics.util.um;

public interface IopenApiCnzz {
	public static final String api_key = "bbb17e06ffd8701baad664394f181a8d";
	public static final String api_secret = "a184f58d5b4f1e4811d8b96c0a5ceeed";
	public static final String Mapi_key = "00dd5c4061d048d8468a0cfa0885cdda";
	public static final String Mapi_secret = "05babd12b763f6b9034aacc052ca0bfe";
}
